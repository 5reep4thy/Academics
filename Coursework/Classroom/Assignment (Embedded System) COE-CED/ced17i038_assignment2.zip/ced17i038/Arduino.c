#include <LiquidCrystal.h>

const int backlight=6;
const int myswitch = 8;

LiquidCrystal lcd(12, 11, 5, 4, 3, 2);

void setup() {
  lcd.begin(16, 2);
  Serial.begin(9600);
  pinMode(backlight,INPUT);
  pinMode(myswitch,OUTPUT);

  
}

void loop() {
  if(digitalRead(myswitch) == HIGH){
    Serial.println("I am in ");
    //static
    lcd.clear();
    analogWrite(backlight,0);
    lcd.setCursor(0, 1);
    lcd.print("Static Text");
    delay(2000);
    
    //Dimming
    lcd.clear();
    analogWrite(backlight,0);
    lcd.setCursor(0, 1);
    lcd.print("Dimming Text");
    for(int i=0;i<128;i++){
      analogWrite(backlight,i);
      delay(10);
    }
    for(int i=128;i>-0;i--){
      analogWrite(backlight,i);
      delay(10);
    }
    delay(1000);
    
    //Blink
    lcd.clear();
    analogWrite(backlight,0);
    lcd.setCursor(0, 0);
    for(int i=0;i<5;i++){
      lcd.print("Blink Text");
      delay(500);
      lcd.clear();
      delay(500);
    }
    delay(1000);
    
    //Scrolling
    lcd.clear();
    analogWrite(backlight,0);
    for(int i=0 ;i<16;i++){
      lcd.setCursor(i, 0);
      lcd.print("Scrolling Text");
      delay(500);
      lcd.clear();
    }
    delay(1000);
  }
  else{
    lcd.clear();
	analogWrite(backlight,0);
    lcd.clear();
    lcd.print("Assignment_2");
    lcd.setCursor(0,1);
    lcd.print("CED17I038");
    delay(1000);
  }
}