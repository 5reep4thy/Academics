#include <LiquidCrystal.h>
#define RS PC_6
#define EN PB_7
#define D4 PA_2
#define D5 PA_3
#define D6 PA_4
#define D7 PB_6
#define light PA_5

LiquidCrystal lcd(RS, EN, D4, D5, D6, D7);
void setup()
{
 lcd.begin(16, 2); 
  pinMode(light, OUTPUT);
}

void blinking()
{
  lcd.setCursor(0,0);  
  analogWrite(light, 128);
  lcd.print("Assignment_2");
  delay(500);
  lcd.clear();
  delay(500);
}

void static()
{
  analogWrite(light, 128);
  lcd.setCursor(0,0); 
  lcd.print("Assignment_2");
}

void scrolling() {
  analogWrite(light, 128);
  lcd.print("Assignment_2");
  delay(100);
  for (int pC = 0; pC < 16; pC++) {
    lcd.scrollDisplayRight();
    delay(150);
  }
  lcd.clear();
  delay(500);

}

void dimming()
{
  lcd.setCursor(0,0); 
  analogWrite(light, 128);
  lcd.print("Assignment_2");
    for(int i=128;i>=0;i++)
    {
        analogWrite(light, i);
        delay(5);
    }
  	for(int i=0;i<128;i++)
    {
  		analogWrite(light, i);
        delay(5);
    }
}

void loop()
{
	for(int i=1; i<16; i++)
	{
		static();
	}
	lcd.clear();
        delay(1000);
	for(int i=1; i<16; i++)
	{
		blinking();
	}
	lcd.clear();
        delay(1000);
	for(int i=1; i<16; i++)
	{
		scrolling();
	}
	lcd.clear();
        delay(1000);
	for(int i=1; i<16; i++)
	{
		dimming();
	}
	lcd.clear();
}
